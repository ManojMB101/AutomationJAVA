package com.qa.assignment.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ResultPage {
	
	@FindBy(linkText="Zero - Free Access to Online Banking")
	WebElement link;
	
	WebDriver driver;

	public ResultPage() {
		PageFactory.initElements(driver, this);
	}
	
}
