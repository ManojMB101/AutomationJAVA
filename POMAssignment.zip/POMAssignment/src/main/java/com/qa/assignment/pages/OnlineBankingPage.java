package com.qa.assignment.pages;

public class OnlineBankingPage {
	//No need to add anything for this scenario
}
