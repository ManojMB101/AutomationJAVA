package com.qa.zerobank.testcase;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LoginPage;
import com.qa.zerobank.pages.ResultPage;
import com.qa.zerobank.util.TestUtil;

public class HomePageTestCases extends TestBase {
	HomePage homepage;
	LoginPage loginpage;
	ResultPage resultPage;
	String path = System.getProperty("user.dir") + "\\src\\main\\java\\com\\qa\\orange\\testdata\\";
//	String name = "Test_Data.xlsx";
//	String Sheetname = "LogIn";

	public HomePageTestCases() {
		super();

	}

	@BeforeTest
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LoginPage();
		resultPage = new ResultPage();

	}

	@AfterTest
	public void quit() {
		TestUtil.TakeScreenshot("Close");
		driver.close();
		driver.quit();

	}

	@Test(priority = 1)
	public void ValidateLoginPage() {
		loginpage.assertLoginPageTitle();
		loginpage.UsernamePassword();
		loginpage.clickOnSignInButton();

	}

	@Test(priority = 2)
	public void ValidateHomepage() {

		homepage.assertHomePageTitle();
		homepage.MovetoRecruitment();
		homepage.movetoCandidates();
		TestUtil.TakeScreenshot("Home");
	}

	@Test(priority = 3)
	public void NavigatetoCandidate() {

		homepage.NavigatetoCandidates();
		resultPage.assertLoginPageTitle();

	}

	@Test(priority = 4)
	public void Addcandidate() {

		resultPage.ClickAddBtn();
		resultPage.Adduser();
		resultPage.AdduseBtn();

	}

	@Test(priority = 5)
	public void VerifyAddcandidate() {
		resultPage.clickCand();
		resultPage.VerfAdduser();

	}

}
