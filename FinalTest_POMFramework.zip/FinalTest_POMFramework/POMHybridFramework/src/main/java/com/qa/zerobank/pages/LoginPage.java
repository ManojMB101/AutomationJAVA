package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.qa.zerobank.base.TestBase;

public class LoginPage extends TestBase {
	
	@FindBy(xpath = "//div[@id='divLogo']/img[1]")
	WebElement Logo;

	@FindBy(id = "btnLogin")
	WebElement LoginInButton;

	@FindBy(id = "txtUsername")
	WebElement UserName;

	@FindBy(id = "txtPassword")
	WebElement Password;

	

	public LoginPage() {

		PageFactory.initElements(driver, this);

	}

	public void assertLoginPageTitle() {

		assertEquals(driver.getTitle(), "OrangeHRM", "Mismatch found");

	}

	public boolean VerifyLogo() {
		return Logo.isDisplayed();
	}

	public void UsernamePassword() {
		UserName.sendKeys(prop.getProperty("userid"));
		Password.sendKeys(prop.getProperty("password"));
	}

	public LoginPage clickOnSignInButton() {

		LoginInButton.click();
		return new LoginPage();
	}
}
