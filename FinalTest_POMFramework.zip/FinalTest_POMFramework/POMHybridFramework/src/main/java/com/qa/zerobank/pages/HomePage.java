package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;


import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;


public class HomePage extends TestBase  {

	@FindBy(xpath="//a[text()='Candidates']")
	WebElement Candidates;
	
	@FindBy(xpath="//div[@id='branding']//img")
	WebElement Logo;
	
	@FindBy(xpath="//b[text()='Recruitment']")
	WebElement Recruitment;
	
	public HomePage() {


		PageFactory.initElements(driver, this);

		}

		public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "OrangeHRM", "Title Mismatch Found");

		}
		
		public boolean VerifyLogo() {
			return Logo.isDisplayed();
		}
		public void MovetoRecruitment() {
			
					
			Actions action = new Actions(driver);

			action.moveToElement(Recruitment).perform();
		}
		public void movetoCandidates() {
			Actions action = new Actions(driver);

			action.moveToElement(Candidates).perform();
			
		}
		public ResultPage NavigatetoCandidates() {
			Candidates.click();
			return new ResultPage();
		}
}
